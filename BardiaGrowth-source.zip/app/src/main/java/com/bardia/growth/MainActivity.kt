package com.bardia.growth

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.bardia.growth.ui.BardiaViewModel
import com.bardia.growth.ui.screens.AddMeasurementScreen
import com.bardia.growth.ui.screens.AddMilestoneScreen
import com.bardia.growth.ui.screens.AddToothScreen
import com.bardia.growth.ui.screens.AddVaccineScreen
import com.bardia.growth.ui.screens.AddWordScreen
import com.bardia.growth.ui.screens.ChartsScreen
import com.bardia.growth.ui.screens.DashboardScreen
import com.bardia.growth.ui.screens.SettingsScreen
import com.bardia.growth.ui.screens.WelcomeSetupScreen
import com.bardia.growth.ui.theme.BardiaGrowthTheme

class MainActivity : ComponentActivity() {
    private val viewModel: BardiaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BardiaGrowthTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    BardiaNavHost(viewModel)
                }
            }
        }
    }
}

@Composable
fun BardiaNavHost(viewModel: BardiaViewModel) {
    val navController: NavHostController = rememberNavController()
    val profile by viewModel.profile.collectAsState()
    val measurements by viewModel.measurements.collectAsState()
    val words by viewModel.words.collectAsState()
    val teeth by viewModel.teeth.collectAsState()
    val milestones by viewModel.milestones.collectAsState()
    val vaccines by viewModel.vaccines.collectAsState()

    // تا وقتی پروفایل بارگذاری نشده یک صفحه‌ی خالی/ساده نشون بده تا از فلیکر جلوگیری بشه
    val currentProfile = profile

    if (currentProfile == null) {
        WelcomeSetupScreen(onSaved = { viewModel.saveProfile(it) })
        return
    }

    NavHost(navController = navController, startDestination = "dashboard") {
        composable("dashboard") {
            DashboardScreen(
                profile = currentProfile,
                measurements = measurements,
                words = words,
                milestones = milestones,
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable("measurement") {
            AddMeasurementScreen(
                onSave = { viewModel.addMeasurement(it); navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }
        composable("word") {
            AddWordScreen(
                onSave = { viewModel.addWord(it); navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }
        composable("tooth") {
            AddToothScreen(
                onSave = { viewModel.addTooth(it); navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }
        composable("milestone") {
            AddMilestoneScreen(
                onSave = { viewModel.addMilestone(it); navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }
        composable("vaccine") {
            AddVaccineScreen(
                onSave = { viewModel.addVaccine(it); navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }
        composable("charts") {
            ChartsScreen(
                profile = currentProfile,
                measurements = measurements,
                words = words,
                teeth = teeth,
                milestones = milestones,
                vaccines = vaccines,
                onBack = { navController.popBackStack() }
            )
        }
        composable("settings") {
            SettingsScreen(
                onExport = { file, cb -> viewModel.exportTo(file, cb) },
                onImport = { file, cb -> viewModel.importFrom(file, cb) },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
