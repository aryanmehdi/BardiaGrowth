package com.bardia.growth.util

import com.bardia.growth.data.BabyProfile
import com.bardia.growth.data.ExportSnapshot
import com.bardia.growth.data.Gender
import com.bardia.growth.data.Measurement
import com.bardia.growth.data.MotorMilestoneEntry
import com.bardia.growth.data.MotorMilestoneType
import com.bardia.growth.data.ToothEntry
import com.bardia.growth.data.ToothPosition
import com.bardia.growth.data.ToothType
import com.bardia.growth.data.VaccineEntry
import com.bardia.growth.data.WordEntry
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * پشتیبان‌گیری کامل و بازگردانی داده‌ها به‌صورت یک فایل JSON. فرمت ساده و خوانا نگه
 * داشته شده تا هم قابل بازرسی دستی باشه و هم در آینده ساده قابل گسترش.
 */
object ExportImport {
    private const val SCHEMA_VERSION = 1

    fun exportToFile(file: File, snapshot: ExportSnapshot) {
        val root = JSONObject()
        root.put("schemaVersion", SCHEMA_VERSION)

        snapshot.profile?.let { p ->
            root.put("profile", JSONObject().apply {
                put("name", p.name)
                put("gender", p.gender.name)
                put("birthDateIso", p.birthDateIso)
                put("birthWeightKg", p.birthWeightKg)
                put("birthHeightCm", p.birthHeightCm)
                put("birthHeadCircumferenceCm", p.birthHeadCircumferenceCm ?: JSONObject.NULL)
            })
        }

        root.put("measurements", JSONArray().apply {
            snapshot.measurements.forEach {
                put(JSONObject().apply {
                    put("dateIso", it.dateIso)
                    put("weightKg", it.weightKg ?: JSONObject.NULL)
                    put("heightCm", it.heightCm ?: JSONObject.NULL)
                    put("headCircumferenceCm", it.headCircumferenceCm ?: JSONObject.NULL)
                    put("note", it.note ?: JSONObject.NULL)
                })
            }
        })

        root.put("words", JSONArray().apply {
            snapshot.words.forEach {
                put(JSONObject().apply {
                    put("word", it.word)
                    put("dateIso", it.dateIso)
                })
            }
        })

        root.put("teeth", JSONArray().apply {
            snapshot.teeth.forEach {
                put(JSONObject().apply {
                    put("position", it.position.name)
                    put("type", it.type.name)
                    put("side", it.side)
                    put("eruptedDateIso", it.eruptedDateIso ?: JSONObject.NULL)
                    put("lostDateIso", it.lostDateIso ?: JSONObject.NULL)
                })
            }
        })

        root.put("milestones", JSONArray().apply {
            snapshot.milestones.forEach {
                put(JSONObject().apply {
                    put("type", it.type.name)
                    put("dateIso", it.dateIso)
                    put("note", it.note ?: JSONObject.NULL)
                })
            }
        })

        root.put("vaccines", JSONArray().apply {
            snapshot.vaccines.forEach {
                put(JSONObject().apply {
                    put("name", it.name)
                    put("dateIso", it.dateIso)
                    put("note", it.note ?: JSONObject.NULL)
                })
            }
        })

        file.writeText(root.toString(2))
    }

    fun importFromFile(file: File): ExportSnapshot {
        val root = JSONObject(file.readText())

        val profile = root.optJSONObject("profile")?.let { p ->
            BabyProfile(
                name = p.getString("name"),
                gender = Gender.valueOf(p.getString("gender")),
                birthDateIso = p.getString("birthDateIso"),
                birthWeightKg = p.getDouble("birthWeightKg"),
                birthHeightCm = p.getDouble("birthHeightCm"),
                birthHeadCircumferenceCm = if (p.isNull("birthHeadCircumferenceCm")) null
                    else p.getDouble("birthHeadCircumferenceCm")
            )
        }

        val measurements = root.optJSONArray("measurements")?.let { arr ->
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Measurement(
                    dateIso = o.getString("dateIso"),
                    weightKg = if (o.isNull("weightKg")) null else o.getDouble("weightKg"),
                    heightCm = if (o.isNull("heightCm")) null else o.getDouble("heightCm"),
                    headCircumferenceCm = if (o.isNull("headCircumferenceCm")) null else o.getDouble("headCircumferenceCm"),
                    note = if (o.isNull("note")) null else o.getString("note")
                )
            }
        } ?: emptyList()

        val words = root.optJSONArray("words")?.let { arr ->
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                WordEntry(word = o.getString("word"), dateIso = o.getString("dateIso"))
            }
        } ?: emptyList()

        val teeth = root.optJSONArray("teeth")?.let { arr ->
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ToothEntry(
                    position = ToothPosition.valueOf(o.getString("position")),
                    type = ToothType.valueOf(o.getString("type")),
                    side = o.getString("side"),
                    eruptedDateIso = if (o.isNull("eruptedDateIso")) null else o.getString("eruptedDateIso"),
                    lostDateIso = if (o.isNull("lostDateIso")) null else o.getString("lostDateIso")
                )
            }
        } ?: emptyList()

        val milestones = root.optJSONArray("milestones")?.let { arr ->
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                MotorMilestoneEntry(
                    type = MotorMilestoneType.valueOf(o.getString("type")),
                    dateIso = o.getString("dateIso"),
                    note = if (o.isNull("note")) null else o.getString("note")
                )
            }
        } ?: emptyList()

        val vaccines = root.optJSONArray("vaccines")?.let { arr ->
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                VaccineEntry(
                    name = o.getString("name"),
                    dateIso = o.getString("dateIso"),
                    note = if (o.isNull("note")) null else o.getString("note")
                )
            }
        } ?: emptyList()

        return ExportSnapshot(profile, measurements, words, teeth, milestones, vaccines)
    }
}
