package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.BabyProfile
import com.bardia.growth.data.Gender
import com.bardia.growth.data.GrowthMeasure
import com.bardia.growth.data.Measurement
import com.bardia.growth.data.MotorMilestoneEntry
import com.bardia.growth.data.ToothEntry
import com.bardia.growth.data.VaccineEntry
import com.bardia.growth.data.WhoStandards
import com.bardia.growth.data.WordEntry
import com.bardia.growth.ui.components.ChartDataPoint
import com.bardia.growth.ui.components.GrowthChart
import com.bardia.growth.util.ShamsiDate
import com.bardia.growth.util.ageInMonthsBetween

private val tabs = listOf("وزن", "قد", "دور سر", "BMI", "کلمات", "دندان", "تجمیعی")

@Composable
fun ChartsScreen(
    profile: BabyProfile,
    measurements: List<Measurement>,
    words: List<WordEntry>,
    teeth: List<ToothEntry>,
    milestones: List<MotorMilestoneEntry>,
    vaccines: List<VaccineEntry>,
    onBack: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    val birth = ShamsiDate.parseIsoLike(profile.birthDateIso)
    fun ageOf(dateIso: String) = ageInMonthsBetween(birth, ShamsiDate.parseIsoLike(dateIso))
    val maxAge = (ageInMonthsBetween(birth, ShamsiDate.today()) + 3).coerceAtLeast(6.0)

    Column(modifier = Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("نمودارها", style = MaterialTheme.typography.headlineMedium)
        TabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }

        when (tab) {
            0 -> GrowthChart(
                title = "نمودار وزن", unit = "کیلوگرم",
                childPoints = measurements.filter { it.weightKg != null }
                    .map { ChartDataPoint(ageOf(it.dateIso), it.weightKg!!) },
                referenceTable = if (profile.gender == Gender.BOY) WhoStandards.weightBoys else WhoStandards.weightGirls,
                measure = GrowthMeasure.WEIGHT, maxAgeMonths = maxAge
            )
            1 -> GrowthChart(
                title = "نمودار قد", unit = "سانتی‌متر",
                childPoints = measurements.filter { it.heightCm != null }
                    .map { ChartDataPoint(ageOf(it.dateIso), it.heightCm!!) },
                referenceTable = if (profile.gender == Gender.BOY) WhoStandards.heightBoys else WhoStandards.heightGirls,
                measure = GrowthMeasure.HEIGHT, maxAgeMonths = maxAge
            )
            2 -> GrowthChart(
                title = "نمودار دور سر", unit = "سانتی‌متر",
                childPoints = measurements.filter { it.headCircumferenceCm != null }
                    .map { ChartDataPoint(ageOf(it.dateIso), it.headCircumferenceCm!!) },
                referenceTable = if (profile.gender == Gender.BOY) WhoStandards.headCircBoys else WhoStandards.headCircGirls,
                measure = GrowthMeasure.HEAD_CIRCUMFERENCE, maxAgeMonths = maxAge
            )
            3 -> {
                val bmiTable = if (profile.gender == Gender.BOY) WhoStandards.weightBoys else WhoStandards.weightGirls
                val heightTable = if (profile.gender == Gender.BOY) WhoStandards.heightBoys else WhoStandards.heightGirls
                // نمودار مرجع BMI به‌صورت پویا از روی جدول وزن/قد ساخته می‌شه (تابع bmiMedianAt)
                GrowthChart(
                    title = "نمودار BMI", unit = "kg/m²",
                    childPoints = measurements.filter { it.bmi != null }
                        .map { ChartDataPoint(ageOf(it.dateIso), it.bmi!!) },
                    referenceTable = bmiTable.map {
                        com.bardia.growth.data.AgePoint(
                            it.ageMonths,
                            WhoStandards.bmiMedianAt(it.ageMonths, bmiTable, heightTable)
                        )
                    },
                    measure = GrowthMeasure.BMI, maxAgeMonths = maxAge
                )
                if (ageInMonthsBetween(birth, ShamsiDate.today()) < 24) {
                    Text(
                        "نکته: BMI زیر ۲ سالگی بر پایه‌ی قد خوابیده حساب می‌شه و به‌تنهایی شاخص خیلی دقیقی نیست؛ بیشتر برای دیدن روند کلی مفیده.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            4 -> {
                Text("تعداد کلمات به مرور زمان (تجمعی): ${words.size} کلمه تا امروز")
                LazyColumn {
                    items(words.sortedBy { it.dateIso }) { w ->
                        Text("• ${w.word} — ${w.dateIso}")
                    }
                }
            }
            5 -> {
                val erupted = teeth.count { it.eruptedDateIso != null }
                val lost = teeth.count { it.lostDateIso != null }
                Text("دندان‌های درآمده: $erupted — دندان‌های افتاده: $lost")
                LazyColumn {
                    items(teeth) { t ->
                        val status = if (t.eruptedDateIso != null) "درآمد در ${t.eruptedDateIso}" else "افتاد در ${t.lostDateIso}"
                        Text("• ${t.side} ${t.type} ($status)")
                    }
                }
            }
            6 -> {
                Text("نمودار تجمیعی: همه‌ی رویدادها روی یک خط زمان", style = MaterialTheme.typography.titleMedium)
                val events = buildList {
                    measurements.forEach { add(it.dateIso to "اندازه‌گیری: وزن=${it.weightKg ?: "-"} قد=${it.heightCm ?: "-"}") }
                    words.forEach { add(it.dateIso to "کلمه‌ی جدید: ${it.word}") }
                    teeth.forEach {
                        if (it.eruptedDateIso != null) add(it.eruptedDateIso to "دندان درآمد: ${it.side} ${it.type}")
                        if (it.lostDateIso != null) add(it.lostDateIso to "دندان افتاد: ${it.side} ${it.type}")
                    }
                    milestones.forEach { add(it.dateIso to "نقطه‌عطف: ${it.type}") }
                    vaccines.forEach { add(it.dateIso to "واکسن: ${it.name}") }
                }.sortedBy { it.first }
                LazyColumn {
                    items(events) { (date, label) ->
                        Text("$date — $label")
                    }
                }
            }
        }

        Button(onClick = onBack) { Text("بازگشت") }
    }
}
