package com.bardia.growth.data

import android.content.Context
import kotlinx.coroutines.flow.Flow

class GrowthRepository(context: Context) {
    private val db = AppDatabase.get(context)

    val profile: Flow<BabyProfile?> = db.babyProfileDao().observe()
    val measurements: Flow<List<Measurement>> = db.measurementDao().observeAll()
    val words: Flow<List<WordEntry>> = db.wordDao().observeAll()
    val teeth: Flow<List<ToothEntry>> = db.toothDao().observeAll()
    val milestones: Flow<List<MotorMilestoneEntry>> = db.motorMilestoneDao().observeAll()
    val vaccines: Flow<List<VaccineEntry>> = db.vaccineDao().observeAll()

    suspend fun getProfile() = db.babyProfileDao().get()
    suspend fun saveProfile(p: BabyProfile) = db.babyProfileDao().upsert(p)

    suspend fun addMeasurement(m: Measurement) = db.measurementDao().insert(m)
    suspend fun deleteMeasurement(m: Measurement) = db.measurementDao().delete(m)

    suspend fun addWord(w: WordEntry) = db.wordDao().insert(w)
    suspend fun deleteWord(w: WordEntry) = db.wordDao().delete(w)

    suspend fun addTooth(t: ToothEntry) = db.toothDao().insert(t)
    suspend fun deleteTooth(t: ToothEntry) = db.toothDao().delete(t)

    suspend fun addMilestone(m: MotorMilestoneEntry) = db.motorMilestoneDao().insert(m)
    suspend fun deleteMilestone(m: MotorMilestoneEntry) = db.motorMilestoneDao().delete(m)

    suspend fun addVaccine(v: VaccineEntry) = db.vaccineDao().insert(v)
    suspend fun deleteVaccine(v: VaccineEntry) = db.vaccineDao().delete(v)

    /** برای Export/Import: خواندن و بازنویسی کامل همه‌ی جدول‌ها. */
    suspend fun getAllForExport(): ExportSnapshot = ExportSnapshot(
        profile = getProfile(),
        measurements = db.measurementDao().getAll(),
        words = db.wordDao().getAll(),
        teeth = db.toothDao().getAll(),
        milestones = db.motorMilestoneDao().getAll(),
        vaccines = db.vaccineDao().getAll()
    )

    suspend fun restoreFromImport(snapshot: ExportSnapshot) {
        snapshot.profile?.let { db.babyProfileDao().upsert(it) }

        db.measurementDao().deleteAll()
        snapshot.measurements.forEach { db.measurementDao().insert(it.copy(id = 0)) }

        db.wordDao().deleteAll()
        snapshot.words.forEach { db.wordDao().insert(it.copy(id = 0)) }

        db.toothDao().deleteAll()
        snapshot.teeth.forEach { db.toothDao().insert(it.copy(id = 0)) }

        db.motorMilestoneDao().deleteAll()
        snapshot.milestones.forEach { db.motorMilestoneDao().insert(it.copy(id = 0)) }

        db.vaccineDao().deleteAll()
        snapshot.vaccines.forEach { db.vaccineDao().insert(it.copy(id = 0)) }
    }
}

data class ExportSnapshot(
    val profile: BabyProfile?,
    val measurements: List<Measurement>,
    val words: List<WordEntry>,
    val teeth: List<ToothEntry>,
    val milestones: List<MotorMilestoneEntry>,
    val vaccines: List<VaccineEntry>
)
