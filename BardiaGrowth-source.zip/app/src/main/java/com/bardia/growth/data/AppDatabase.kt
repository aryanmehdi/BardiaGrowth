package com.bardia.growth.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        BabyProfile::class,
        Measurement::class,
        WordEntry::class,
        ToothEntry::class,
        MotorMilestoneEntry::class,
        VaccineEntry::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun babyProfileDao(): BabyProfileDao
    abstract fun measurementDao(): MeasurementDao
    abstract fun wordDao(): WordDao
    abstract fun toothDao(): ToothDao
    abstract fun motorMilestoneDao(): MotorMilestoneDao
    abstract fun vaccineDao(): VaccineDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bardia-growth.db"
                ).build().also { instance = it }
            }
    }
}
