package com.bardia.growth.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BabyProfileDao {
    @Query("SELECT * FROM baby_profile WHERE id = 1 LIMIT 1")
    fun observe(): Flow<BabyProfile?>

    @Query("SELECT * FROM baby_profile WHERE id = 1 LIMIT 1")
    suspend fun get(): BabyProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: BabyProfile)
}

@Dao
interface MeasurementDao {
    @Query("SELECT * FROM measurements ORDER BY dateIso ASC")
    fun observeAll(): Flow<List<Measurement>>

    @Query("SELECT * FROM measurements ORDER BY dateIso ASC")
    suspend fun getAll(): List<Measurement>

    @Insert
    suspend fun insert(m: Measurement): Long

    @Delete
    suspend fun delete(m: Measurement)

    @Query("DELETE FROM measurements")
    suspend fun deleteAll()
}

@Dao
interface WordDao {
    @Query("SELECT * FROM words ORDER BY dateIso ASC")
    fun observeAll(): Flow<List<WordEntry>>

    @Query("SELECT * FROM words ORDER BY dateIso ASC")
    suspend fun getAll(): List<WordEntry>

    @Insert
    suspend fun insert(w: WordEntry): Long

    @Delete
    suspend fun delete(w: WordEntry)

    @Query("DELETE FROM words")
    suspend fun deleteAll()
}

@Dao
interface ToothDao {
    @Query("SELECT * FROM teeth ORDER BY eruptedDateIso ASC")
    fun observeAll(): Flow<List<ToothEntry>>

    @Query("SELECT * FROM teeth ORDER BY eruptedDateIso ASC")
    suspend fun getAll(): List<ToothEntry>

    @Insert
    suspend fun insert(t: ToothEntry): Long

    @Delete
    suspend fun delete(t: ToothEntry)

    @Query("DELETE FROM teeth")
    suspend fun deleteAll()
}

@Dao
interface MotorMilestoneDao {
    @Query("SELECT * FROM motor_milestones ORDER BY dateIso ASC")
    fun observeAll(): Flow<List<MotorMilestoneEntry>>

    @Query("SELECT * FROM motor_milestones ORDER BY dateIso ASC")
    suspend fun getAll(): List<MotorMilestoneEntry>

    @Insert
    suspend fun insert(m: MotorMilestoneEntry): Long

    @Delete
    suspend fun delete(m: MotorMilestoneEntry)

    @Query("DELETE FROM motor_milestones")
    suspend fun deleteAll()
}

@Dao
interface VaccineDao {
    @Query("SELECT * FROM vaccines ORDER BY dateIso ASC")
    fun observeAll(): Flow<List<VaccineEntry>>

    @Query("SELECT * FROM vaccines ORDER BY dateIso ASC")
    suspend fun getAll(): List<VaccineEntry>

    @Insert
    suspend fun insert(v: VaccineEntry): Long

    @Delete
    suspend fun delete(v: VaccineEntry)

    @Query("DELETE FROM vaccines")
    suspend fun deleteAll()
}
