package com.bardia.growth.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Gender { BOY, GIRL }

/**
 * پروفایل کودک. طراحی شده تا برای هر کودکی (نه فقط بردیا) قابل استفاده باشه، چون
 * جنسیت و تاریخ تولد در همین جدول ذخیره می‌شه و انتخابیه.
 */
@Entity(tableName = "baby_profile")
data class BabyProfile(
    @PrimaryKey val id: Int = 1, // یک اپ فعلاً برای یک کودک؛ آماده برای گسترش به چند پروفایل در آینده
    val name: String,
    val gender: Gender,
    val birthDateIso: String,       // تاریخ شمسی به فرمت YYYY-MM-DD
    val birthWeightKg: Double,
    val birthHeightCm: Double,
    val birthHeadCircumferenceCm: Double? = null
)

@Entity(tableName = "measurements")
data class Measurement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateIso: String,
    val weightKg: Double? = null,
    val heightCm: Double? = null,
    val headCircumferenceCm: Double? = null,
    val note: String? = null
) {
    val bmi: Double?
        get() {
            val w = weightKg ?: return null
            val h = heightCm ?: return null
            if (h <= 0) return null
            val hMeters = h / 100.0
            return w / (hMeters * hMeters)
        }
}

@Entity(tableName = "words")
data class WordEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val word: String,
    val dateIso: String
)

enum class ToothPosition { UPPER, LOWER }
enum class ToothType { CENTRAL_INCISOR, LATERAL_INCISOR, CANINE, FIRST_MOLAR, SECOND_MOLAR }

@Entity(tableName = "teeth")
data class ToothEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val position: ToothPosition,
    val type: ToothType,
    val side: String,               // "چپ" یا "راست"
    val eruptedDateIso: String? = null,
    val lostDateIso: String? = null
)

enum class MotorMilestoneType {
    SITTING_WITHOUT_SUPPORT, STANDING_WITH_ASSISTANCE, CRAWLING,
    WALKING_WITH_ASSISTANCE, STANDING_ALONE, WALKING_ALONE, FIRST_SMILE, OTHER
}

@Entity(tableName = "motor_milestones")
data class MotorMilestoneEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: MotorMilestoneType,
    val dateIso: String,
    val note: String? = null
)

@Entity(tableName = "vaccines")
data class VaccineEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dateIso: String,
    val note: String? = null
)
