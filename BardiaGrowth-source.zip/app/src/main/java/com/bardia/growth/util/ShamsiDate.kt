package com.bardia.growth.util

import java.util.Calendar

/**
 * تبدیل دقیق بین تاریخ شمسی (جلالی) و میلادی.
 *
 * این پیاده‌سازی بر پایه‌ی الگوریتم شناخته‌شده و آزموده‌شده‌ی jalaali (بر اساس کارهای
 * روزبه پورنادر و بهروز محمدی) نوشته شده که تمام کبیسه‌های تقویم شمسی را با دقت
 * روزانه، برای بازه‌ی سال‌های ۶۱- تا ۳۱۷۷ شمسی محاسبه می‌کند؛ یعنی بازه‌ی مورد نیاز
 * ما (۱۴۰۵ تا ۱۴۱۵) با اطمینان کامل پوشش داده می‌شود.
 */
data class ShamsiDate(val year: Int, val month: Int, val day: Int) : Comparable<ShamsiDate> {

    override fun compareTo(other: ShamsiDate): Int {
        if (year != other.year) return year - other.year
        if (month != other.month) return month - other.month
        return day - other.day
    }

    fun toDisplayString(): String {
        val months = listOf(
            "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
        )
        return "$day ${months[month - 1]} $year"
    }

    fun toIsoLikeString(): String = "%04d-%02d-%02d".format(year, month, day)

    companion object {
        fun fromMillis(millis: Long): ShamsiDate {
            val cal = Calendar.getInstance()
            cal.timeInMillis = millis
            return ShamsiConverter.gregorianToJalali(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH)
            )
        }

        fun today(): ShamsiDate = fromMillis(System.currentTimeMillis())

        fun parseIsoLike(s: String): ShamsiDate {
            val parts = s.split("-")
            return ShamsiDate(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
        }
    }
}

/** تعداد روزهای هر ماه شمسی (غیرکبیسه)، برای نمایش تقویم و اعتبارسنجی ورودی. */
fun daysInJalaliMonth(year: Int, month: Int): Int = when {
    month in 1..6 -> 31
    month in 7..11 -> 30
    month == 12 -> if (ShamsiConverter.isLeapJalaliYear(year)) 30 else 29
    else -> throw IllegalArgumentException("ماه نامعتبر: $month")
}

/**
 * محاسبه‌ی سن دقیق بر حسب روز/ماه بین دو تاریخ شمسی (برای مثال بین تاریخ تولد و تاریخ
 * اندازه‌گیری) از طریق تبدیل هر دو به روز-ژولیَن، تا محاسبه کاملاً مستقل از طول متغیر
 * ماه‌های شمسی و دقیق باشد.
 */
fun ageInDaysBetween(birth: ShamsiDate, on: ShamsiDate): Int {
    val jdnBirth = ShamsiConverter.jalaliToJdn(birth.year, birth.month, birth.day)
    val jdnOn = ShamsiConverter.jalaliToJdn(on.year, on.month, on.day)
    return jdnOn - jdnBirth
}

fun ageInMonthsBetween(birth: ShamsiDate, on: ShamsiDate): Double =
    ageInDaysBetween(birth, on) / 30.4368 // میانگین طول ماه میلادی، برای تطبیق با جداول سنی-به-ماه WHO

/**
 * هسته‌ی الگوریتم تبدیل. تمام محاسبات با اعداد صحیح و بر پایه‌ی شماره‌ی روز ژولیَن (JDN)
 * انجام می‌شود تا از خطای انباشته جلوگیری شود.
 */
internal object ShamsiConverter {

    private val breaks = intArrayOf(
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
        1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    )

    private fun div(a: Int, b: Int): Int = a / b
    private fun mod(a: Int, b: Int): Int = a - (a / b) * b

    private data class JalCal(val leap: Int, val gy: Int, val march: Int)

    private fun jalCal(jy: Int): JalCal {
        val bl = breaks.size
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        require(jy >= jp && jy < breaks[bl - 1]) { "سال شمسی نامعتبر: $jy" }

        var jump = 0
        var i = 1
        while (i < bl) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4)
            jp = jm
            i += 1
        }
        var n = jy - jp
        leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4)
        if (mod(jump, 33) == 4 && jump - n == 4) leapJ += 1

        val leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150
        val march = 20 + leapJ - leapG

        if (jump - n < 6) {
            n = n - jump + div(jump + 4, 33) * 33
        }
        var leap = mod(mod(n + 1, 33) - 1, 4)
        if (leap == -1) leap = 4

        return JalCal(leap, gy, march)
    }

    private fun g2d(gy: Int, gm: Int, gd: Int): Int {
        var d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
            div(153 * mod(gm + 9, 12) + 2, 5) +
            gd - 34840408
        d -= div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) - 752
        return d
    }

    private fun d2g(jdn: Int): Triple<Int, Int, Int> {
        var j = 4 * jdn + 139361631
        j += div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908
        val i = div(mod(j, 1461), 4) * 5 + 308
        val gd = div(mod(i, 153), 5) + 1
        val gm = mod(div(i, 153), 12) + 1
        val gy = div(j, 1461) - 100100 + div(8 - gm, 6)
        return Triple(gy, gm, gd)
    }

    fun jalaliToJdn(jy: Int, jm: Int, jd: Int): Int {
        val r = jalCal(jy)
        return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1
    }

    fun isLeapJalaliYear(jy: Int): Boolean = jalCal(jy).leap == 0

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): ShamsiDate {
        val jdn = g2d(gy, gm, gd)
        var gy2 = d2g(jdn).first
        var jy = gy2 - 621
        var r = jalCal(jy)
        var jdn1f = g2d(r.gy, 3, r.march)
        var k = jdn - jdn1f
        val jm: Int
        val jd: Int
        if (k >= 0) {
            if (k <= 185) {
                jm = 1 + div(k, 31)
                jd = mod(k, 31) + 1
                return ShamsiDate(jy, jm, jd)
            } else {
                k -= 186
            }
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1) k += 1
        }
        jm = 7 + div(k, 30)
        jd = mod(k, 30) + 1
        return ShamsiDate(jy, jm, jd)
    }

    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jdn = jalaliToJdn(jy, jm, jd)
        return d2g(jdn)
    }
}
