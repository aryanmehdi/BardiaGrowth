package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.MotorMilestoneEntry
import com.bardia.growth.data.MotorMilestoneType
import com.bardia.growth.ui.components.ShamsiDatePickerRow
import com.bardia.growth.util.ShamsiDate

private val milestoneLabels = mapOf(
    MotorMilestoneType.SITTING_WITHOUT_SUPPORT to "نشستن بدون کمک",
    MotorMilestoneType.STANDING_WITH_ASSISTANCE to "ایستادن با کمک",
    MotorMilestoneType.CRAWLING to "چهار دست‌وپا رفتن",
    MotorMilestoneType.WALKING_WITH_ASSISTANCE to "راه رفتن با کمک",
    MotorMilestoneType.STANDING_ALONE to "ایستادن مستقل",
    MotorMilestoneType.WALKING_ALONE to "راه رفتن مستقل",
    MotorMilestoneType.FIRST_SMILE to "اولین لبخند",
    MotorMilestoneType.OTHER to "سایر"
)

@Composable
fun AddMilestoneScreen(onSave: (MotorMilestoneEntry) -> Unit, onBack: () -> Unit) {
    var type by remember { mutableStateOf(MotorMilestoneType.WALKING_ALONE) }
    var date by remember { mutableStateOf(ShamsiDate.today()) }

    Column(modifier = Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ثبت نقطه‌عطف حرکتی", style = MaterialTheme.typography.headlineMedium)

        Text("نوع", style = MaterialTheme.typography.titleMedium)
        milestoneLabels.forEach { (t, label) ->
            Row {
                RadioButton(selected = type == t, onClick = { type = t })
                Text(label, modifier = Modifier.padding(top = 12.dp))
            }
        }

        Text("تاریخ (شمسی)", style = MaterialTheme.typography.titleMedium)
        ShamsiDatePickerRow(date = date, onDateChange = { date = it })

        Column {
            Button(onClick = { onSave(MotorMilestoneEntry(type = type, dateIso = date.toIsoLikeString())) }) {
                Text("ذخیره")
            }
            Button(onClick = onBack) { Text("بازگشت") }
        }
    }
}
