package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.WordEntry
import com.bardia.growth.ui.components.ShamsiDatePickerRow
import com.bardia.growth.util.ShamsiDate

@Composable
fun AddWordScreen(onSave: (WordEntry) -> Unit, onBack: () -> Unit) {
    var word by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(ShamsiDate.today()) }

    Column(modifier = Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ثبت کلمه‌ی جدید", style = MaterialTheme.typography.headlineMedium)
        Text("از صفحه‌کلید مجازی (با ایرموس) برای تایپ کلمه استفاده کن.")

        OutlinedTextField(value = word, onValueChange = { word = it }, label = { Text("کلمه") })

        Text("تاریخ اولین باری که گفته (شمسی)", style = MaterialTheme.typography.titleMedium)
        ShamsiDatePickerRow(date = date, onDateChange = { date = it })

        Column {
            Button(onClick = {
                if (word.isNotBlank()) onSave(WordEntry(word = word.trim(), dateIso = date.toIsoLikeString()))
            }) { Text("ذخیره") }
            Button(onClick = onBack) { Text("بازگشت") }
        }
    }
}
