package com.bardia.growth.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bardia.growth.data.AgePoint
import com.bardia.growth.data.GrowthMeasure
import com.bardia.growth.data.WhoStandards
import com.bardia.growth.ui.theme.BardiaGreen
import com.bardia.growth.ui.theme.BardiaYellow

data class ChartDataPoint(val ageMonths: Double, val value: Double)

/**
 * نموداری که داده‌ی واقعی کودک رو (خط زرد پررنگ) روی باند صدک نرمال WHO (سبز کم‌رنگ،
 * صدک ۳ تا ۹۷، و باندی پررنگ‌تر برای صدک ۱۵ تا ۸۵) رسم می‌کنه.
 */
@Composable
fun GrowthChart(
    title: String,
    unit: String,
    childPoints: List<ChartDataPoint>,
    referenceTable: List<AgePoint>?,
    measure: GrowthMeasure,
    maxAgeMonths: Double = 24.0,
    modifier: Modifier = Modifier
) {
    Text(text = "$title ($unit)", style = MaterialTheme.typography.titleMedium)
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
    ) {
        val leftPad = 60f
        val bottomPad = 40f
        val topPad = 20f
        val rightPad = 20f
        val chartW = size.width - leftPad - rightPad
        val chartH = size.height - topPad - bottomPad

        val ageMax = maxAgeMonths.coerceAtLeast(1.0)

        // محدوده‌ی محور Y بر اساس داده‌های مرجع و داده‌ی واقعی کودک
        val refValuesForRange = referenceTable?.let { table ->
            (0..40).map { i ->
                val age = ageMax * i / 40.0
                val median = WhoStandards.medianAt(age, table)
                WhoStandards.percentileValue(median, measure, WhoStandards.Z_P97)
            }
        } ?: emptyList()
        val childValues = childPoints.map { it.value }
        val allValues = refValuesForRange + childValues
        val minY = (allValues.minOrNull() ?: 0.0) * 0.85
        val maxY = (allValues.maxOrNull() ?: 1.0) * 1.15

        fun xFor(age: Double) = leftPad + (age / ageMax).coerceIn(0.0, 1.0).toFloat() * chartW
        fun yFor(v: Double) =
            topPad + chartH - ((v - minY) / (maxY - minY)).coerceIn(0.0, 1.0).toFloat() * chartH

        // محورها
        drawLine(Color.Gray, Offset(leftPad, topPad), Offset(leftPad, topPad + chartH), strokeWidth = 2f)
        drawLine(Color.Gray, Offset(leftPad, topPad + chartH), Offset(leftPad + chartW, topPad + chartH), strokeWidth = 2f)

        // باندهای صدک نرمال (کم‌رنگ)
        if (referenceTable != null) {
            val steps = 40
            val p97 = mutableListOf<Offset>()
            val p3 = mutableListOf<Offset>()
            val p85 = mutableListOf<Offset>()
            val p15 = mutableListOf<Offset>()
            val median = mutableListOf<Offset>()
            for (i in 0..steps) {
                val age = ageMax * i / steps
                val med = WhoStandards.medianAt(age, referenceTable)
                p97.add(Offset(xFor(age), yFor(WhoStandards.percentileValue(med, measure, WhoStandards.Z_P97))))
                p3.add(Offset(xFor(age), yFor(WhoStandards.percentileValue(med, measure, WhoStandards.Z_P3))))
                p85.add(Offset(xFor(age), yFor(WhoStandards.percentileValue(med, measure, WhoStandards.Z_P85))))
                p15.add(Offset(xFor(age), yFor(WhoStandards.percentileValue(med, measure, WhoStandards.Z_P15))))
                median.add(Offset(xFor(age), yFor(med)))
            }
            val outerBand = androidx.compose.ui.graphics.Path().apply {
                moveTo(p3.first().x, p3.first().y)
                p3.forEach { lineTo(it.x, it.y) }
                for (i in p97.indices.reversed()) lineTo(p97[i].x, p97[i].y)
                close()
            }
            drawPath(outerBand, color = BardiaGreen.copy(alpha = 0.12f))

            val innerBand = androidx.compose.ui.graphics.Path().apply {
                moveTo(p15.first().x, p15.first().y)
                p15.forEach { lineTo(it.x, it.y) }
                for (i in p85.indices.reversed()) lineTo(p85[i].x, p85[i].y)
                close()
            }
            drawPath(innerBand, color = BardiaGreen.copy(alpha = 0.22f))

            for (i in 0 until median.size - 1) {
                drawLine(
                    BardiaGreen.copy(alpha = 0.6f),
                    median[i], median[i + 1],
                    strokeWidth = 2f,
                    cap = StrokeCap.Round
                )
            }
        }

        // داده‌ی واقعی کودک
        val sorted = childPoints.sortedBy { it.ageMonths }
        for (i in 0 until sorted.size - 1) {
            drawLine(
                BardiaYellow,
                Offset(xFor(sorted[i].ageMonths), yFor(sorted[i].value)),
                Offset(xFor(sorted[i + 1].ageMonths), yFor(sorted[i + 1].value)),
                strokeWidth = 5f,
                cap = StrokeCap.Round
            )
        }
        sorted.forEach {
            drawCircle(BardiaYellow, radius = 6f, center = Offset(xFor(it.ageMonths), yFor(it.value)))
        }
    }
}
