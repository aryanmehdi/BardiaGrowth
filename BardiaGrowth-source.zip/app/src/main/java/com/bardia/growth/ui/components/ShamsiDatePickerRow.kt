package com.bardia.growth.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.util.ShamsiDate
import com.bardia.growth.util.daysInJalaliMonth

@Composable
fun ShamsiDatePickerRow(
    date: ShamsiDate,
    onDateChange: (ShamsiDate) -> Unit,
    minYear: Int = 1405,
    maxYear: Int = 1415
) {
    Row {
        StepperField("سال", date.year, minYear, maxYear) { newYear ->
            val maxDay = daysInJalaliMonth(newYear, date.month)
            onDateChange(date.copy(year = newYear, day = date.day.coerceAtMost(maxDay)))
        }
        Spacer(Modifier.width(12.dp))
        StepperField("ماه", date.month, 1, 12) { newMonth ->
            val maxDay = daysInJalaliMonth(date.year, newMonth)
            onDateChange(date.copy(month = newMonth, day = date.day.coerceAtMost(maxDay)))
        }
        Spacer(Modifier.width(12.dp))
        StepperField("روز", date.day, 1, daysInJalaliMonth(date.year, date.month)) { newDay ->
            onDateChange(date.copy(day = newDay))
        }
    }
}

@Composable
private fun StepperField(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row {
        IconButton(onClick = { if (value > min) onChange(value - 1) }) {
            Icon(Icons.Filled.Remove, contentDescription = "$label کمتر")
        }
        Text(text = "$label: $value", modifier = androidx.compose.ui.Modifier.width(84.dp))
        IconButton(onClick = { if (value < max) onChange(value + 1) }) {
            Icon(Icons.Filled.Add, contentDescription = "$label بیشتر")
        }
    }
}
