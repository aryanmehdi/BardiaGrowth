package com.bardia.growth.data

/**
 * داده‌های مرجع رشد.
 *
 * نکته‌ی مهم و صادقانه: مقادیر میانه (median) این جدول بر اساس نمودارهای منتشرشده‌ی
 * WHO Child Growth Standards (۰ تا ۶۰ ماهگی) نوشته شده و به‌طور معمول با دقت خوبی
 * منطبق‌اند، اما این فایل شامل جدول کامل و رسمی LMS (که خود WHO به‌صورت فایل
 * Excel/CSV منتشر کرده) نیست. باندهای صدک (P3 تا P97) اینجا با یک تقریب آماری
 * (انحراف‌معیار تقریبی حول میانه) رسم می‌شن، نه از روی جدول دقیق LMS.
 * برای استفاده‌ی روزمره و دیدن روند رشد بردیا نسبت به محدوده‌ی طبیعی، این تقریب
 * کاملاً کاربردیه؛ اگر در آینده خواستی دقت کاملاً بالینی داشته باشه، می‌شه جدول
 * دقیق LMS رسمی رو (از who.int) جایگزین همین فایل کرد بدون تغییر در بقیه‌ی اپ.
 */
data class AgePoint(val ageMonths: Double, val median: Double)

enum class GrowthMeasure(val approxRelativeSd: Double) {
    WEIGHT(0.13),
    HEIGHT(0.045),
    HEAD_CIRCUMFERENCE(0.032),
    BMI(0.11)
}

object WhoStandards {

    // میانه‌ی وزن (کیلوگرم) به تفکیک سن (ماه)
    val weightBoys = listOf(
        AgePoint(0.0, 3.3), AgePoint(1.0, 4.5), AgePoint(2.0, 5.6), AgePoint(3.0, 6.4),
        AgePoint(4.0, 7.0), AgePoint(5.0, 7.5), AgePoint(6.0, 7.9), AgePoint(7.0, 8.3),
        AgePoint(8.0, 8.6), AgePoint(9.0, 8.9), AgePoint(10.0, 9.2), AgePoint(11.0, 9.4),
        AgePoint(12.0, 9.6), AgePoint(15.0, 10.3), AgePoint(18.0, 10.9), AgePoint(21.0, 11.5),
        AgePoint(24.0, 12.2), AgePoint(30.0, 13.3), AgePoint(36.0, 14.3), AgePoint(42.0, 15.3),
        AgePoint(48.0, 16.3), AgePoint(54.0, 17.2), AgePoint(60.0, 18.3)
    )
    val weightGirls = listOf(
        AgePoint(0.0, 3.2), AgePoint(1.0, 4.2), AgePoint(2.0, 5.1), AgePoint(3.0, 5.8),
        AgePoint(4.0, 6.4), AgePoint(5.0, 6.9), AgePoint(6.0, 7.3), AgePoint(7.0, 7.6),
        AgePoint(8.0, 7.9), AgePoint(9.0, 8.2), AgePoint(10.0, 8.5), AgePoint(11.0, 8.7),
        AgePoint(12.0, 8.9), AgePoint(15.0, 9.6), AgePoint(18.0, 10.2), AgePoint(21.0, 10.9),
        AgePoint(24.0, 11.5), AgePoint(30.0, 12.7), AgePoint(36.0, 13.9), AgePoint(42.0, 14.8),
        AgePoint(48.0, 15.9), AgePoint(54.0, 16.8), AgePoint(60.0, 18.0)
    )

    // میانه‌ی قد/طول (سانتی‌متر)
    val heightBoys = listOf(
        AgePoint(0.0, 49.9), AgePoint(1.0, 54.7), AgePoint(2.0, 58.4), AgePoint(3.0, 61.4),
        AgePoint(4.0, 63.9), AgePoint(5.0, 65.9), AgePoint(6.0, 67.6), AgePoint(7.0, 69.2),
        AgePoint(8.0, 70.6), AgePoint(9.0, 72.0), AgePoint(10.0, 73.3), AgePoint(11.0, 74.5),
        AgePoint(12.0, 75.7), AgePoint(15.0, 79.1), AgePoint(18.0, 82.3), AgePoint(21.0, 85.1),
        AgePoint(24.0, 87.8), AgePoint(30.0, 91.9), AgePoint(36.0, 96.1), AgePoint(42.0, 99.9),
        AgePoint(48.0, 103.3), AgePoint(54.0, 106.7), AgePoint(60.0, 110.0)
    )
    val heightGirls = listOf(
        AgePoint(0.0, 49.1), AgePoint(1.0, 53.7), AgePoint(2.0, 57.1), AgePoint(3.0, 59.8),
        AgePoint(4.0, 62.1), AgePoint(5.0, 64.0), AgePoint(6.0, 65.7), AgePoint(7.0, 67.3),
        AgePoint(8.0, 68.7), AgePoint(9.0, 70.1), AgePoint(10.0, 71.5), AgePoint(11.0, 72.8),
        AgePoint(12.0, 74.0), AgePoint(15.0, 77.5), AgePoint(18.0, 80.7), AgePoint(21.0, 83.7),
        AgePoint(24.0, 86.4), AgePoint(30.0, 90.7), AgePoint(36.0, 95.1), AgePoint(42.0, 99.0),
        AgePoint(48.0, 102.7), AgePoint(54.0, 106.2), AgePoint(60.0, 109.4)
    )

    // میانه‌ی دور سر (سانتی‌متر)
    val headCircBoys = listOf(
        AgePoint(0.0, 34.5), AgePoint(1.0, 37.3), AgePoint(2.0, 39.1), AgePoint(3.0, 40.5),
        AgePoint(4.0, 41.6), AgePoint(5.0, 42.6), AgePoint(6.0, 43.3), AgePoint(7.0, 44.0),
        AgePoint(8.0, 44.5), AgePoint(9.0, 45.0), AgePoint(10.0, 45.4), AgePoint(11.0, 45.8),
        AgePoint(12.0, 46.1), AgePoint(15.0, 46.9), AgePoint(18.0, 47.4), AgePoint(21.0, 47.9),
        AgePoint(24.0, 48.3), AgePoint(30.0, 49.0), AgePoint(36.0, 49.5), AgePoint(42.0, 49.9),
        AgePoint(48.0, 50.2), AgePoint(54.0, 50.4), AgePoint(60.0, 50.6)
    )
    val headCircGirls = listOf(
        AgePoint(0.0, 33.9), AgePoint(1.0, 36.5), AgePoint(2.0, 38.3), AgePoint(3.0, 39.5),
        AgePoint(4.0, 40.6), AgePoint(5.0, 41.5), AgePoint(6.0, 42.2), AgePoint(7.0, 42.8),
        AgePoint(8.0, 43.4), AgePoint(9.0, 43.8), AgePoint(10.0, 44.2), AgePoint(11.0, 44.6),
        AgePoint(12.0, 44.9), AgePoint(15.0, 45.7), AgePoint(18.0, 46.2), AgePoint(21.0, 46.7),
        AgePoint(24.0, 47.1), AgePoint(30.0, 47.9), AgePoint(36.0, 48.5), AgePoint(42.0, 48.9),
        AgePoint(48.0, 49.3), AgePoint(54.0, 49.6), AgePoint(60.0, 49.9)
    )

    fun medianAt(ageMonths: Double, table: List<AgePoint>): Double {
        if (ageMonths <= table.first().ageMonths) return table.first().median
        if (ageMonths >= table.last().ageMonths) return table.last().median
        for (i in 0 until table.size - 1) {
            val a = table[i]
            val b = table[i + 1]
            if (ageMonths in a.ageMonths..b.ageMonths) {
                val t = (ageMonths - a.ageMonths) / (b.ageMonths - a.ageMonths)
                return a.median + t * (b.median - a.median)
            }
        }
        return table.last().median
    }

    fun bmiMedianAt(ageMonths: Double, weightTable: List<AgePoint>, heightTable: List<AgePoint>): Double {
        val w = medianAt(ageMonths, weightTable)
        val hCm = medianAt(ageMonths, heightTable)
        val hM = hCm / 100.0
        return w / (hM * hM)
    }

    /** مقدار یک صدک مشخص (z-score تقریبی) حول میانه، با انحراف‌معیار تقریبی هر شاخص. */
    fun percentileValue(median: Double, measure: GrowthMeasure, z: Double): Double =
        median + z * measure.approxRelativeSd * median

    // z-scoreهای استاندارد متناظر با صدک‌های رایج
    const val Z_P3 = -1.881
    const val Z_P15 = -1.036
    const val Z_P50 = 0.0
    const val Z_P85 = 1.036
    const val Z_P97 = 1.881
}

/** بازه‌ی نرمال نقاط‌عطف حرکتی (WHO Motor Development Study)؛ بدون تفکیک جنسیتی چون
 * تفاوت معناداری بین پسر و دختر در این پژوهش مشاهده نشد. */
object MotorMilestoneRanges {
    val ranges: Map<MotorMilestoneType, ClosedFloatingPointRange<Double>> = mapOf(
        MotorMilestoneType.SITTING_WITHOUT_SUPPORT to 3.8..9.2,
        MotorMilestoneType.STANDING_WITH_ASSISTANCE to 4.8..11.4,
        MotorMilestoneType.CRAWLING to 5.2..13.5,
        MotorMilestoneType.WALKING_WITH_ASSISTANCE to 5.9..13.7,
        MotorMilestoneType.STANDING_ALONE to 6.9..16.9,
        MotorMilestoneType.WALKING_ALONE to 8.2..17.6
    )
}

/** بازه‌ی معمول کلمات فعال (تعداد کلمه به تفکیک سن) — بازه‌ای بسیار گسترده و صرفاً راهنما،
 * نه یک استاندارد صدکی دقیق (چنین استانداردی برای زبان وجود نداره). */
object WordCountGuide {
    val approxByMonth: List<Pair<Double, IntRange>> = listOf(
        12.0 to 1..3,
        15.0 to 3..10,
        18.0 to 10..50,
        24.0 to 50..200
    )
}

/** بازه‌ی معمول دندان‌درآوری اولیه (منبع: چارت‌های رایج دندان‌پزشکی کودکان). */
object ToothEruptionRanges {
    data class Range(val minMonths: Double, val maxMonths: Double)

    val ranges: Map<ToothType, Range> = mapOf(
        ToothType.CENTRAL_INCISOR to Range(6.0, 12.0),
        ToothType.LATERAL_INCISOR to Range(9.0, 16.0),
        ToothType.FIRST_MOLAR to Range(13.0, 19.0),
        ToothType.CANINE to Range(16.0, 22.0),
        ToothType.SECOND_MOLAR to Range(23.0, 33.0)
    )
}
