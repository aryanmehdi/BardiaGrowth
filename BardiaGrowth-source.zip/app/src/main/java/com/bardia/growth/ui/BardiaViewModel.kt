package com.bardia.growth.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bardia.growth.data.BabyProfile
import com.bardia.growth.data.GrowthRepository
import com.bardia.growth.data.Measurement
import com.bardia.growth.data.MotorMilestoneEntry
import com.bardia.growth.data.ToothEntry
import com.bardia.growth.data.VaccineEntry
import com.bardia.growth.data.WordEntry
import com.bardia.growth.util.ExportImport
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class BardiaViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = GrowthRepository(application)

    val profile: StateFlow<BabyProfile?> =
        repo.profile.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val measurements: StateFlow<List<Measurement>> =
        repo.measurements.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val words: StateFlow<List<WordEntry>> =
        repo.words.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val teeth: StateFlow<List<ToothEntry>> =
        repo.teeth.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val milestones: StateFlow<List<MotorMilestoneEntry>> =
        repo.milestones.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vaccines: StateFlow<List<VaccineEntry>> =
        repo.vaccines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveProfile(p: BabyProfile) = viewModelScope.launch { repo.saveProfile(p) }
    fun addMeasurement(m: Measurement) = viewModelScope.launch { repo.addMeasurement(m) }
    fun deleteMeasurement(m: Measurement) = viewModelScope.launch { repo.deleteMeasurement(m) }
    fun addWord(w: WordEntry) = viewModelScope.launch { repo.addWord(w) }
    fun deleteWord(w: WordEntry) = viewModelScope.launch { repo.deleteWord(w) }
    fun addTooth(t: ToothEntry) = viewModelScope.launch { repo.addTooth(t) }
    fun deleteTooth(t: ToothEntry) = viewModelScope.launch { repo.deleteTooth(t) }
    fun addMilestone(m: MotorMilestoneEntry) = viewModelScope.launch { repo.addMilestone(m) }
    fun deleteMilestone(m: MotorMilestoneEntry) = viewModelScope.launch { repo.deleteMilestone(m) }
    fun addVaccine(v: VaccineEntry) = viewModelScope.launch { repo.addVaccine(v) }
    fun deleteVaccine(v: VaccineEntry) = viewModelScope.launch { repo.deleteVaccine(v) }

    fun exportTo(file: File, onDone: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            try {
                val snapshot = repo.getAllForExport()
                ExportImport.exportToFile(file, snapshot)
                onDone(true, null)
            } catch (e: Exception) {
                onDone(false, e.message)
            }
        }
    }

    fun importFrom(file: File, onDone: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            try {
                val snapshot = ExportImport.importFromFile(file)
                repo.restoreFromImport(snapshot)
                onDone(true, null)
            } catch (e: Exception) {
                onDone(false, e.message)
            }
        }
    }
}
