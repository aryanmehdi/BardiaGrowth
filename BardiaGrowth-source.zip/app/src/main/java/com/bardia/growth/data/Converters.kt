package com.bardia.growth.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun genderToString(g: Gender): String = g.name

    @TypeConverter
    fun stringToGender(s: String): Gender = Gender.valueOf(s)

    @TypeConverter
    fun toothPositionToString(p: ToothPosition): String = p.name

    @TypeConverter
    fun stringToToothPosition(s: String): ToothPosition = ToothPosition.valueOf(s)

    @TypeConverter
    fun toothTypeToString(t: ToothType): String = t.name

    @TypeConverter
    fun stringToToothType(s: String): ToothType = ToothType.valueOf(s)

    @TypeConverter
    fun motorTypeToString(t: MotorMilestoneType): String = t.name

    @TypeConverter
    fun stringToMotorType(s: String): MotorMilestoneType = MotorMilestoneType.valueOf(s)
}
