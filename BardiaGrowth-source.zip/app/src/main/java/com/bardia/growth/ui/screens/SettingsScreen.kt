package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

private const val BACKUP_FILE_NAME = "bardia-growth-backup.json"

@Composable
fun SettingsScreen(
    onExport: (File, (Boolean, String?) -> Unit) -> Unit,
    onImport: (File, (Boolean, String?) -> Unit) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val backupFile = File(context.getExternalFilesDir(null) ?: context.filesDir, BACKUP_FILE_NAME)

    Column(modifier = Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("تنظیمات", style = MaterialTheme.typography.headlineMedium)

        Text("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium)
        Text("محل فایل پشتیبان: ${backupFile.absolutePath}", style = MaterialTheme.typography.bodySmall)

        Button(onClick = {
            onExport(backupFile) { success, error ->
                statusMessage = if (success) "پشتیبان با موفقیت در فایل بالا ذخیره شد."
                else "خطا در پشتیبان‌گیری: $error"
            }
        }) { Text("Export — گرفتن نسخه پشتیبان") }

        Button(onClick = {
            if (backupFile.exists()) {
                onImport(backupFile) { success, error ->
                    statusMessage = if (success) "داده‌ها با موفقیت از فایل پشتیبان بازیابی شدند."
                    else "خطا در بازیابی: $error"
                }
            } else {
                statusMessage = "هیچ فایل پشتیبانی در مسیر بالا پیدا نشد."
            }
        }) { Text("Import — بازیابی از نسخه پشتیبان") }

        statusMessage?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }

        Text(
            "توجه: برای انتقال داده به یک تلویزیون دیگر، فایل بالا رو (از طریق یک فایل‌منیجر یا اتصال USB) کپی کن و روی دستگاه جدید در همون مسیر بذار، بعد Import رو بزن.",
            style = MaterialTheme.typography.bodySmall
        )

        Button(onClick = onBack) { Text("بازگشت") }
    }
}
