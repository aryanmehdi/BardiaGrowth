package com.bardia.growth.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.round

/**
 * فیلد ورود عدد اعشاری، مناسب کنترل با ریموت: هم می‌شه با صفحه‌کلید تلویزیون تایپ کرد
 * هم با دکمه‌های +/- (که با فوکوس ریموت و دکمه‌ی OK کار می‌کنن) عدد رو step کرد.
 */
@Composable
fun NumberField(
    label: String,
    value: Double?,
    onValueChange: (Double?) -> Unit,
    step: Double = 0.1,
    modifier: Modifier = Modifier
) {
    fun roundTo2(v: Double) = round(v * 100.0) / 100.0

    Row(modifier = modifier) {
        IconButton(onClick = { onValueChange(roundTo2((value ?: 0.0) - step)) }) {
            Icon(Icons.Filled.Remove, contentDescription = "کم کردن")
        }
        Spacer(Modifier.width(4.dp))
        OutlinedTextField(
            value = value?.toString() ?: "",
            onValueChange = { text ->
                val cleaned = text.replace(",", ".")
                val parsed = cleaned.toDoubleOrNull()
                onValueChange(if (cleaned.isEmpty()) null else (parsed?.let { roundTo2(it) } ?: value))
            },
            label = { Text(label) },
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.width(160.dp)
        )
        Spacer(Modifier.width(4.dp))
        IconButton(onClick = { onValueChange(roundTo2((value ?: 0.0) + step)) }) {
            Icon(Icons.Filled.Add, contentDescription = "زیاد کردن")
        }
    }
}
