package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.ToothEntry
import com.bardia.growth.data.ToothPosition
import com.bardia.growth.data.ToothType
import com.bardia.growth.ui.components.ShamsiDatePickerRow
import com.bardia.growth.util.ShamsiDate

private val toothTypeLabels = mapOf(
    ToothType.CENTRAL_INCISOR to "ثنایای مرکزی",
    ToothType.LATERAL_INCISOR to "ثنایای جانبی",
    ToothType.CANINE to "نیش",
    ToothType.FIRST_MOLAR to "آسیای اول",
    ToothType.SECOND_MOLAR to "آسیای دوم"
)

@Composable
fun AddToothScreen(onSave: (ToothEntry) -> Unit, onBack: () -> Unit) {
    var type by remember { mutableStateOf(ToothType.CENTRAL_INCISOR) }
    var position by remember { mutableStateOf(ToothPosition.LOWER) }
    var side by remember { mutableStateOf("چپ") }
    var date by remember { mutableStateOf(ShamsiDate.today()) }
    var isLoss by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ثبت دندان", style = MaterialTheme.typography.headlineMedium)

        Text("نوع رویداد", style = MaterialTheme.typography.titleMedium)
        Row {
            Row { RadioButton(selected = !isLoss, onClick = { isLoss = false }); Text("درآمدن", modifier = Modifier.padding(top = 12.dp, end = 16.dp)) }
            Row { RadioButton(selected = isLoss, onClick = { isLoss = true }); Text("افتادن", modifier = Modifier.padding(top = 12.dp)) }
        }

        Text("نوع دندان", style = MaterialTheme.typography.titleMedium)
        LazyRow {
            items(ToothType.values().toList()) { t ->
                Row(Modifier.padding(end = 12.dp)) {
                    RadioButton(selected = type == t, onClick = { type = t })
                    Text(toothTypeLabels[t] ?: t.name, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }

        Text("فک", style = MaterialTheme.typography.titleMedium)
        Row {
            Row { RadioButton(selected = position == ToothPosition.LOWER, onClick = { position = ToothPosition.LOWER }); Text("پایین", modifier = Modifier.padding(top = 12.dp, end = 16.dp)) }
            Row { RadioButton(selected = position == ToothPosition.UPPER, onClick = { position = ToothPosition.UPPER }); Text("بالا", modifier = Modifier.padding(top = 12.dp)) }
        }

        Text("سمت", style = MaterialTheme.typography.titleMedium)
        Row {
            Row { RadioButton(selected = side == "چپ", onClick = { side = "چپ" }); Text("چپ", modifier = Modifier.padding(top = 12.dp, end = 16.dp)) }
            Row { RadioButton(selected = side == "راست", onClick = { side = "راست" }); Text("راست", modifier = Modifier.padding(top = 12.dp)) }
        }

        Text("تاریخ (شمسی)", style = MaterialTheme.typography.titleMedium)
        ShamsiDatePickerRow(date = date, onDateChange = { date = it })

        Column {
            Button(onClick = {
                onSave(
                    ToothEntry(
                        position = position,
                        type = type,
                        side = side,
                        eruptedDateIso = if (!isLoss) date.toIsoLikeString() else null,
                        lostDateIso = if (isLoss) date.toIsoLikeString() else null
                    )
                )
            }) { Text("ذخیره") }
            Button(onClick = onBack) { Text("بازگشت") }
        }
    }
}
