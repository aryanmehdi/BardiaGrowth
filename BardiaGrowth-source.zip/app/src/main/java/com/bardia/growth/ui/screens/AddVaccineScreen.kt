package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.VaccineEntry
import com.bardia.growth.ui.components.ShamsiDatePickerRow
import com.bardia.growth.util.ShamsiDate

@Composable
fun AddVaccineScreen(onSave: (VaccineEntry) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(ShamsiDate.today()) }
    var note by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ثبت واکسن", style = MaterialTheme.typography.headlineMedium)
        Text("نام واکسن رو آزادانه بنویس، چون برنامه‌ی واکسیناسیون رسمی هرازگاهی به‌روزرسانی می‌شه.")

        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام واکسن") })

        Text("تاریخ تزریق (شمسی)", style = MaterialTheme.typography.titleMedium)
        ShamsiDatePickerRow(date = date, onDateChange = { date = it })

        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("یادداشت (اختیاری)") })

        Column {
            Button(onClick = {
                if (name.isNotBlank()) {
                    onSave(VaccineEntry(name = name.trim(), dateIso = date.toIsoLikeString(), note = note.ifBlank { null }))
                }
            }) { Text("ذخیره") }
            Button(onClick = onBack) { Text("بازگشت") }
        }
    }
}
