package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.BabyProfile
import com.bardia.growth.data.Gender
import com.bardia.growth.ui.components.NumberField
import com.bardia.growth.ui.components.ShamsiDatePickerRow
import com.bardia.growth.util.ShamsiDate

@Composable
fun WelcomeSetupScreen(onSaved: (BabyProfile) -> Unit) {
    var name by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf(Gender.BOY) }
    var birthDate by remember { mutableStateOf(ShamsiDate.today()) }
    var birthWeight by remember { mutableStateOf<Double?>(3.3) }
    var birthHeight by remember { mutableStateOf<Double?>(50.0) }
    var birthHc by remember { mutableStateOf<Double?>(34.5) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("خوش اومدی به بردیا رشد", style = MaterialTheme.typography.headlineMedium)
        Text("برای شروع، اطلاعات اولیه‌ی نوزاد رو وارد کن.", style = MaterialTheme.typography.bodyMedium)

        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام کودک") })

        Text("جنسیت", style = MaterialTheme.typography.titleMedium)
        Row {
            Row {
                RadioButton(selected = gender == Gender.BOY, onClick = { gender = Gender.BOY })
                Text("پسر", modifier = Modifier.padding(top = 12.dp, end = 16.dp))
            }
            Row {
                RadioButton(selected = gender == Gender.GIRL, onClick = { gender = Gender.GIRL })
                Text("دختر", modifier = Modifier.padding(top = 12.dp))
            }
        }

        Text("تاریخ تولد (شمسی)", style = MaterialTheme.typography.titleMedium)
        ShamsiDatePickerRow(date = birthDate, onDateChange = { birthDate = it })

        Text("وزن هنگام تولد (کیلوگرم)", style = MaterialTheme.typography.titleMedium)
        NumberField(label = "کیلوگرم", value = birthWeight, onValueChange = { birthWeight = it }, step = 0.05)

        Text("قد هنگام تولد (سانتی‌متر)", style = MaterialTheme.typography.titleMedium)
        NumberField(label = "سانتی‌متر", value = birthHeight, onValueChange = { birthHeight = it }, step = 0.5)

        Text("دور سر هنگام تولد (سانتی‌متر) — اختیاری", style = MaterialTheme.typography.titleMedium)
        NumberField(label = "سانتی‌متر", value = birthHc, onValueChange = { birthHc = it }, step = 0.5)

        Button(
            onClick = {
                onSaved(
                    BabyProfile(
                        name = name.ifBlank { "کودک" },
                        gender = gender,
                        birthDateIso = birthDate.toIsoLikeString(),
                        birthWeightKg = birthWeight ?: 3.3,
                        birthHeightCm = birthHeight ?: 50.0,
                        birthHeadCircumferenceCm = birthHc
                    )
                )
            }
        ) {
            Text("ذخیره و شروع")
        }
    }
}
