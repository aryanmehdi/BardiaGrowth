package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.BabyProfile
import com.bardia.growth.data.Measurement
import com.bardia.growth.data.MotorMilestoneEntry
import com.bardia.growth.data.WordEntry
import com.bardia.growth.util.ShamsiDate
import com.bardia.growth.util.ageInMonthsBetween

@Composable
fun DashboardScreen(
    profile: BabyProfile,
    measurements: List<Measurement>,
    words: List<WordEntry>,
    milestones: List<MotorMilestoneEntry>,
    onNavigate: (String) -> Unit
) {
    val birth = ShamsiDate.parseIsoLike(profile.birthDateIso)
    val today = ShamsiDate.today()
    val ageMonths = ageInMonthsBetween(birth, today)
    val lastMeasurement = measurements.maxByOrNull { it.dateIso }

    Column(modifier = Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("سلام! داشبورد ${profile.name}", style = MaterialTheme.typography.headlineMedium)
        Text("سن فعلی: حدود ${"%.1f".format(ageMonths)} ماه", style = MaterialTheme.typography.bodyLarge)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("آخرین اندازه‌گیری", style = MaterialTheme.typography.titleMedium)
                if (lastMeasurement == null) {
                    Text("هنوز اندازه‌گیری‌ای ثبت نشده.")
                } else {
                    Text("تاریخ: ${lastMeasurement.dateIso}")
                    lastMeasurement.weightKg?.let { Text("وزن: $it کیلوگرم") }
                    lastMeasurement.heightCm?.let { Text("قد: $it سانتی‌متر") }
                    lastMeasurement.headCircumferenceCm?.let { Text("دور سر: $it سانتی‌متر") }
                    lastMeasurement.bmi?.let { Text("BMI: ${"%.1f".format(it)}") }
                }
                Text("تعداد کلمات ثبت‌شده: ${words.size}")
                Text("نقاط عطف حرکتی ثبت‌شده: ${milestones.size}")
            }
        }

        Text("دسترسی سریع", style = MaterialTheme.typography.titleMedium)
        LazyRow {
            items(
                listOf(
                    "measurement" to "ثبت اندازه‌گیری",
                    "word" to "ثبت کلمه جدید",
                    "tooth" to "ثبت دندان",
                    "milestone" to "ثبت نقطه‌عطف",
                    "vaccine" to "ثبت واکسن",
                    "charts" to "نمودارها",
                    "settings" to "تنظیمات"
                )
            ) { (route, label) ->
                Button(onClick = { onNavigate(route) }, modifier = Modifier.padding(end = 8.dp)) {
                    Text(label)
                }
            }
        }
    }
}
