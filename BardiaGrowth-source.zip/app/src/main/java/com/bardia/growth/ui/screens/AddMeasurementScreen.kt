package com.bardia.growth.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bardia.growth.data.Measurement
import com.bardia.growth.ui.components.NumberField
import com.bardia.growth.ui.components.ShamsiDatePickerRow
import com.bardia.growth.util.ShamsiDate

@Composable
fun AddMeasurementScreen(onSave: (Measurement) -> Unit, onBack: () -> Unit) {
    var date by remember { mutableStateOf(ShamsiDate.today()) }
    var weight by remember { mutableStateOf<Double?>(null) }
    var height by remember { mutableStateOf<Double?>(null) }
    var hc by remember { mutableStateOf<Double?>(null) }
    var note by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ثبت اندازه‌گیری جدید", style = MaterialTheme.typography.headlineMedium)

        Text("تاریخ (شمسی)", style = MaterialTheme.typography.titleMedium)
        ShamsiDatePickerRow(date = date, onDateChange = { date = it })

        Text("وزن (کیلوگرم)", style = MaterialTheme.typography.titleMedium)
        NumberField(label = "کیلوگرم", value = weight, onValueChange = { weight = it }, step = 0.05)

        Text("قد (سانتی‌متر)", style = MaterialTheme.typography.titleMedium)
        NumberField(label = "سانتی‌متر", value = height, onValueChange = { height = it }, step = 0.5)

        Text("دور سر (سانتی‌متر)", style = MaterialTheme.typography.titleMedium)
        NumberField(label = "سانتی‌متر", value = hc, onValueChange = { hc = it }, step = 0.2)

        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("یادداشت (اختیاری)") })

        Column {
            Button(onClick = {
                onSave(
                    Measurement(
                        dateIso = date.toIsoLikeString(),
                        weightKg = weight,
                        heightCm = height,
                        headCircumferenceCm = hc,
                        note = note.ifBlank { null }
                    )
                )
            }) { Text("ذخیره") }
            Button(onClick = onBack) { Text("بازگشت") }
        }
    }
}
