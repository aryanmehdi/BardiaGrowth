package com.bardia.growth.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// هویت بصری اپ: زرد گرم به‌عنوان رنگ اصلی/اکشن، سبز به‌عنوان رنگ ثانویه/تاییدکننده
val BardiaYellow = Color(0xFFFFC107)
val BardiaYellowDark = Color(0xFFB28900)
val BardiaGreen = Color(0xFF4CAF50)
val BardiaGreenDark = Color(0xFF2E7D32)
val BardiaBackground = Color(0xFF13140F) // پس‌زمینه‌ی گرم و تیره، مناسب دیدن از فاصله روی تلویزیون
val BardiaSurface = Color(0xFF1E2018)
val BardiaOnSurface = Color(0xFFF5F1E6)
val BardiaError = Color(0xFFE57373)

private val BardiaColorScheme = darkColorScheme(
    primary = BardiaYellow,
    onPrimary = Color.Black,
    secondary = BardiaGreen,
    onSecondary = Color.Black,
    tertiary = BardiaGreenDark,
    background = BardiaBackground,
    onBackground = BardiaOnSurface,
    surface = BardiaSurface,
    onSurface = BardiaOnSurface,
    error = BardiaError
)

@Composable
fun BardiaGrowthTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BardiaColorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
